class DetectiveRobot extends Robot {

public void saySomething()
{
    System.out.println("Ich suche Paco");
}
}