class ReadingRobot extends Robot {

public void saySomething()
{
    System.out.println("ich lese Nachrichten");
}
}