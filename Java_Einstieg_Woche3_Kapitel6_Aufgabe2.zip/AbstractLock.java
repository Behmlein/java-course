abstract public class AbstractLock {
    int numberOfAttempts;

 abstract boolean openWithSecretNumber();
 
 abstract boolean openWithSecretWord();
}
