class Robot {
void testNumber(int pruefer){
    int TestErgebnis;
    TestErgebnis = pruefer / 2;
    
    if (TestErgebnis == 0)
    {
        System.out.println("Die Zahl ist durch 2 teilbar!");
    }
    else{
        System.out.println("Die Zahl ist nicht durch 2 teilbar!");
    }
}

}
