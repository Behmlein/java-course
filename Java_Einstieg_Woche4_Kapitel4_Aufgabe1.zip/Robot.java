import java.util.ArrayList;

public class Robot {

public void giveAccessCodes(ArrayList Eingabe)
{
    ArrayList<String> Ausgabe = new ArrayList<>();
    
    Ausgabe = Eingabe;
    for(String s : Ausgabe)
    {
        System.out.println(s);
    }
}
}
