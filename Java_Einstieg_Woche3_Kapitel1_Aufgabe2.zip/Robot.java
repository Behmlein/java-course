class Robot {
	int batteryRuntime;
	boolean canSpeak;

}
