class DecodeRobot {

public void tap(String eingabe1, int eingabe2)
{
    for(int i = 0;i<eingabe2;i++)
    {
        System.out.println(eingabe1);
    }
}
public void tap(String eingabe3)
{
    this.tap(eingabe3,3);
}
}
