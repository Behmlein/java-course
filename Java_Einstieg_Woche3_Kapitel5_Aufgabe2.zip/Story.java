class Story {    
	public static void main(String[] args) {
	    DecodeRobot decodeRobot = new DecodeRobot();
        decodeRobot.tap("firstCode");
        decodeRobot.tap("secondCode", 5);
    }
}
