class Story {

    public static void main(String[] args) {
    	Robot ronja  = new Robot("Robin finden.");
    	Robot rob = new Robot();
    	System.out.println(ronja.task);
    	System.out.println(rob.task);
    }
}
