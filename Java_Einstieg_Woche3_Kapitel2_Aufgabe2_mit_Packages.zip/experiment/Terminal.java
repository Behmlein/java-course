package experiment;

public class Terminal {

public void hackRobot(TestRobot Robot) {
    
    System.out.println(Robot.numberOfProcessorCores);
    
}

}
