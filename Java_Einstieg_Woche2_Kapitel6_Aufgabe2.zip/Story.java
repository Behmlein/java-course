class Story {

    public static void main(String[] args) {
        Task findPaco = new Task("Prof.-Dr.-Helmert-Straße 2");
        System.out.println(findPaco.position);
    }

}
