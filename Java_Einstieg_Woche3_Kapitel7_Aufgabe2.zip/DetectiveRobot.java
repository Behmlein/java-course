class DetectiveRobot extends Robot{

    DetectiveRobot() {
        batteryRuntime = 10;
    }

}
