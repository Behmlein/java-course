class Robot {

    void countTo(int number){
        for (int i = 0; i < 21; i++){
            System.out.println("Zahl ist: " + i);
        }
    }


}