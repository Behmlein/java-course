class Robot {
    int batteryRuntime;

    Robot() {
        this.batteryRuntime = 5;
    }

}
